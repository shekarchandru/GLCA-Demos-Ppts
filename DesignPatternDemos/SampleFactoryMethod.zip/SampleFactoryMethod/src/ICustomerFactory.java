
public interface ICustomerFactory 
{
	 ICustomer createCustomer();
}
