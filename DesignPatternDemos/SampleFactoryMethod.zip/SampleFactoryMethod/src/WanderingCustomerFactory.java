
public class WanderingCustomerFactory implements ICustomerFactory
{

	@Override
	public ICustomer createCustomer() 
	{
		// TODO Auto-generated method stub
		Object customer = new WanderingCustomer();
        return (ICustomer) customer;
		
	}

}
