
public class LoyalCustomer implements ICustomer 
{

	@Override
	public void displayCustomer() {
		// TODO Auto-generated method stub
		System.out.println("DISPLAYING LOYAL CUSTOMER DETAILS");
	}

}
