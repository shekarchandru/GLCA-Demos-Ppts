
public class WanderingCustomer implements ICustomer
{

	@Override
	public void displayCustomer() {
		// TODO Auto-generated method stub
		System.out.println("DISPLAYING WANDERING CUSTOMER DETAILS");
	}

}
