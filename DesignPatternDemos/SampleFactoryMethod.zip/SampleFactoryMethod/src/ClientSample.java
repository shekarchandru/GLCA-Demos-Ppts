
public class ClientSample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ICustomer ic ;
		//USING REFLECTION CLASSES
		ICustomerFactory icf;
		icf = new DiscountCustomerFactory();
		ic = icf.createCustomer();
		ic.displayCustomer();
		
		icf = new LoyalCustomerFactory();
		 ic = icf.createCustomer();
		 ic.displayCustomer();
		

	}

}
