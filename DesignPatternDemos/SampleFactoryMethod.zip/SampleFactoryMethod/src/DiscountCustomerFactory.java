
public class DiscountCustomerFactory implements ICustomerFactory
{

	@Override
	public ICustomer createCustomer() {
		// TODO Auto-generated method stub
		
		Object customer = new DiscountCustomer();
        return (ICustomer) customer;
	}

}
