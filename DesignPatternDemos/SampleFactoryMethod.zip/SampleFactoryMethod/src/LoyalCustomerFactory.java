
public class LoyalCustomerFactory implements ICustomerFactory
{

	@Override
	public ICustomer createCustomer() {
		// TODO Auto-generated method stub
		Object customer = new LoyalCustomer();
        return (ICustomer) customer;
	}
	
}
