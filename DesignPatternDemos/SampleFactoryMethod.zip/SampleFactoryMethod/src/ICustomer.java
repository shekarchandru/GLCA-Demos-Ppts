
public interface ICustomer 
{
	void displayCustomer();
}
