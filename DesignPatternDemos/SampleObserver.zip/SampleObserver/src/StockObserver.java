
public class StockObserver implements Observer
{
	
	//SUBSCRIBER OBSERVER LISTENER	
	private double ibmPrice;
	private double aaplPrice;
	private double googPrice;
	
	private static int observerIDTracker = 0;
	private int observerID;
	
	private Subject stockGrabber;//Observable
	
	public StockObserver(Subject stockGrabber)
	{
		this.stockGrabber=stockGrabber;
		this.observerID=++observerIDTracker;
		System.out.println("New Observer "+this.observerID);
		stockGrabber.register(this);
	}
	
	@Override
	public void update(double aaplPrice, double ibmPrice, double googPrice) {
		// TODO Auto-generated method stub
		this.aaplPrice=aaplPrice;
		this.ibmPrice=ibmPrice;
		this.googPrice=googPrice;
		printThePrices();
		
	}
	public void printThePrices()
	{
		System.out.println(observerID+"\nAAPL :"+aaplPrice+"\n IBM "+ibmPrice+"\nGOOG :"+googPrice);
	}
}











