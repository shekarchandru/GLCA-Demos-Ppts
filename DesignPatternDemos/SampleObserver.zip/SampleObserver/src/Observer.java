
public interface Observer {

	public void update(double aaplPrice,double ibmPrice,double googPrice);
}
