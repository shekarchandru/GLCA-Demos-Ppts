import java.util.Calendar;
import java.util.Date;


public class ClientProg {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// ShoppingMall mall1 = new ShoppingMall(new LowDiscountStrategy());
     /*   mall1.customerName = "Monday Customer";
         mall1.billAmount = 1000;
         System.out.println("The Final Bill " + mall1.getMyBill());
         
         ShoppingMall mall2 = new ShoppingMall(new HighDiscountStrategy());
         mall2.customerName = "Thursday Customer";
         mall2.billAmount = 1000;
         System.out.println("The Final Bill " + mall2.getMyBill());

         ShoppingMall mall3 = new ShoppingMall(new NoDiscountStrategy());
         mall3.customerName = "Weekend Customer";
         mall3.billAmount = 1000;
         System.out.println("The Final Bill " + mall3.getMyBill());
*/

         

         ShoppingMall mall = new ShoppingMall(null);
         mall.customerName = "X Customer";
         mall.billAmount = 1000;

         Date d=new Date();
         String days[]={"Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"};
         Calendar myCal=Calendar.getInstance();
        String strDay= days[(myCal.get(Calendar.DAY_OF_WEEK))-1];
        System.out.println("The day is"+(myCal.get(Calendar.DAY_OF_WEEK)-1));
         switch(strDay)
         {
             case "Tuesday":
                 {
                     mall.currentStrategy = new LowDiscountStrategy();
                     break;

                 }
             case "Monday":
                 {
                     mall.currentStrategy = new HighDiscountStrategy();
                     break;
                 }
             case "Saturday":
                 {
                     mall.currentStrategy = new NoDiscountStrategy();
                     break;
                 }
             default:
                 {
                     mall.currentStrategy = null;
                     break;
                 }
         }
         System.out.println("The Bill amount is Through" + mall.getMyBill());
        // Console.ReadLine();
         /* * Date d=new Date();
		System.out.println(d);
		String month[]={"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};

		Calendar myCal=Calendar.getInstance();
		System.out.println("The Month is :"+month[myCal.get(Calendar.MONTH)]);
		System.out.println("The YEAR is :"+myCal.get(Calendar.YEAR));
		System.out.println("The DATE is :"+myCal.get(Calendar.DATE));
*/
	}

}
