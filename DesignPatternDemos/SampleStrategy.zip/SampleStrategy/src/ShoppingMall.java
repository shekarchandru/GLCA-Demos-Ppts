
public class ShoppingMall {

	 public String customerName;
     public int billAmount;

    

    public  IStrategy currentStrategy;
     public ShoppingMall(IStrategy strategy)
     {
         currentStrategy = strategy;
     }
     public int getMyBill()
     {
         return currentStrategy.getFinalBill(this.billAmount);
     }
}
