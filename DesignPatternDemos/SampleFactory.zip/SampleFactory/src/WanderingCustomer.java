
public class WanderingCustomer implements ICustomer
{

	@Override
	public void displayCustomer() {
		// TODO Auto-generated method stub
		System.out.println("The Customer is WANDERING CUSTOMER");
		
	}

}
