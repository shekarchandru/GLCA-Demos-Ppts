
public interface ICustomer 
{

	public void displayCustomer();
}

