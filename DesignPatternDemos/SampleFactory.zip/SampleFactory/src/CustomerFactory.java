public class CustomerFactory 
{
	public static ICustomer createInstance(String strType)
	{
		ICustomer customer=null;
		
		if(strType==null)
		{
			return null;
		}
		else if("discount".equalsIgnoreCase(strType))
		{
			return new DiscountCustomer();
		}
		else if("loyal".equalsIgnoreCase(strType))
		{
			return new LoyalCustomer();
		}
		else if("regular".equalsIgnoreCase(strType))
		{
			return new RegularCustomer();
		}
		else if("wandering".equalsIgnoreCase(strType))
		{
			return new WanderingCustomer();
		}
		else
		{
			return null;
		}
		
	}

}
