import java.util.Random;
//adaptee
public class EnemeyRobot 
{
	
	Random generator=new Random();
	
	public void smashWithHands()
	{
		int attackDamage=generator.nextInt(10)+1;
		System.out.println("Enemy Robot Causes "+attackDamage+" Damage with its Hands");
	}
	public void walkForward()
	{
		int movement=generator.nextInt(5);
		System.out.println("Enemy Robot walks forward "+movement+" Spaces");
		
	}
	public void reactToHuman(String driver)
	{
		System.out.println("Enemy Robot tramps on "+driver);
	}

}
