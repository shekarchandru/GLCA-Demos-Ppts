//Adapter Implementing Target
//Responsibilit adapting the Adaptee according to the Targets need
public class EnemyRobotAdapter implements EnemyAttacker{

	EnemeyRobot theRobot;
	
	public EnemyRobotAdapter(EnemeyRobot newRobot)
	{
		theRobot=newRobot;
	}
	@Override
	public void fireWeapon()  
	{
		theRobot.smashWithHands();
		
	}

	@Override
	public void driveForward() {
		theRobot.walkForward();
		
	}

	@Override
	public void assignDriver(String driver)
	{
		theRobot.reactToHuman(driver);
		
	}

}
