
public class TestEnemyAttackers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		EnemyTank rx7Tank=new EnemyTank();
		
		EnemeyRobot fredTheRobot=new EnemeyRobot();
		
		EnemyAttacker robotAdapter=new EnemyRobotAdapter(fredTheRobot);
		
		System.out.println("The Robot");
		
		fredTheRobot.reactToHuman("Paul");
		fredTheRobot.walkForward();
		fredTheRobot.smashWithHands();
		
		System.out.println("The Enemy Tank");
		
		rx7Tank.assignDriver("Frank");
		rx7Tank.driveForward();
		rx7Tank.fireWeapon();
		
		System.out.println("The Robot with Adapter");
		
		robotAdapter.assignDriver("Mark");
		robotAdapter.driveForward();
		robotAdapter.fireWeapon();
	}

}
