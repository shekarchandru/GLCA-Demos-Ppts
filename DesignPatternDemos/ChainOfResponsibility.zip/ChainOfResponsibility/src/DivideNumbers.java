
public class DivideNumbers implements Chain
{
	private Chain nextInChain;
	@Override
	public void setNextChain(Chain nextChain) {
		// TODO Auto-generated method stub
		this.nextInChain=nextChain;
	}

	@Override
	public void calculate(Numbers request) {
		// TODO Auto-generated method stub
		if(request.calculationWanted() == "Div")
		{
			System.out.println(request.getNumber1() +" / "+request.getNumber2()+" = "+(request.getNumber1() / request.getNumber2()));
		}
		else
		{
			System.out.println("Only Operations Add,Subtract,Multiply or Divide could be performed....");
		}
	}
}
