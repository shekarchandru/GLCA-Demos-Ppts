
public class TestCalcInChain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

			Chain chainCalc1=new AddNumbers();
			Chain chainCalc2=new SubtractNumbers();
			Chain chainCalc3=new MultiNumbers();
			Chain chainCalc4=new DivideNumbers();
			
			chainCalc1.setNextChain(chainCalc2);
			chainCalc2.setNextChain(chainCalc3);
			chainCalc3.setNextChain(chainCalc4);
			
			Numbers request=new Numbers(2,4,"Add");
			chainCalc1.calculate(request);/**/
			
			Numbers requests=new Numbers(2,4,"Add");
			chainCalc1.calculate(requests);/**/
			
			Numbers request1=new Numbers(2,4,"Multi");
			chainCalc1.calculate(request1);/**/
			
			Numbers request2=new Numbers(20,4,"Sub");
			chainCalc1.calculate(request2);	/**/
			
			Numbers request3=new Numbers(20,4,"Div");
			chainCalc1.calculate(request3);/**/
			
			Numbers request4=new Numbers(20,4,"Div1");
			chainCalc2.calculate(request4); /*	*/
			}

		//DEREK BANAS
}
