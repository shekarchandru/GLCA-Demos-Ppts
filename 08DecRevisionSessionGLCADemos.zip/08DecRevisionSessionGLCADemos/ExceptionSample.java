
public class ExceptionSample {

	
	public void checkException()
	{
		int arr[] = new int[10];
		System.out.println("Manipulating array");
		for(int i=0;i<11;i++)
		{
			/**/try
			{ 
				arr[i] = (i+1)*10;
			}
			//catch(ArrayIndexOutOfBoundsException ae)
			catch(Exception e)
			{
				System.out.println(e.getMessage());
				e.printStackTrace();
				
			}/**/
			System.out.println(" array element is"+arr[i]);
		}
		System.out.println("Manipulated array ");
	}
	public void divide(int num1,int num2)
	{
		int result;
		try
		{
			result = num1 / num2;
			System.out.println(result);
		}
		catch(ArithmeticException ae)
		{
			ae.printStackTrace();
			//System.out.println(ae.getMessage());
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ExceptionSample esam = new ExceptionSample();
		System.out.println("calling arraymethod");
		/*try
		{*/
	//		esam.checkException();
		/*}
		catch(Exception ex)
		{
			System.out.println(ex.getMessage());
		}*/
		esam.divide(10, 5);
		esam.divide(10, 0);
		System.out.println("called arraymethod");

	}

}
