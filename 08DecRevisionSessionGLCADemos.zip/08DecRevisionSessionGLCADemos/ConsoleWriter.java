import java.io.BufferedOutputStream;
import java.io.IOException;

public class ConsoleWriter {

	BufferedOutputStream bos;
	byte mybytes [] = new byte[100];
	String str="We are writing onto Console";
	public void writeToConsoleThruBuffer()
	{
	//	bos = new BufferedOutputStream(new FileOutputStream(new File("supplier.txt")));
		bos = new BufferedOutputStream(System.out);
		mybytes = str.getBytes();
		try {
			bos.write(mybytes);
			System.out.println("We have written onto console...");
			bos.flush();
			bos.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ConsoleWriter cw = new ConsoleWriter();
		cw.writeToConsoleThruBuffer();

	}

}
