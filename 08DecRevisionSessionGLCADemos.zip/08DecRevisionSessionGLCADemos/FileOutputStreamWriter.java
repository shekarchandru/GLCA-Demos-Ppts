import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileOutputStreamWriter {

	FileOutputStream fos;
	String str = "We are writing to file through STreams";
	byte[] mybytes = new byte[100];
	public void writeToStream()
	{
		File file1 = new File("customer.txt");
		try {
			fos = new FileOutputStream(file1);
			mybytes = str.getBytes();
			fos.write(mybytes);
			fos.flush();
			fos.close();
			System.out.println("Written into file successfully...");

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			e.getMessage();
		} catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FileOutputStreamWriter fosw = new FileOutputStreamWriter();
		fosw.writeToStream();

	}

}
