import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class FileWriterClass {

	FileWriter fw;
	String str = "We are writing to Char STream";
	public void writeToFileThruWriter()
	{
		File file1 = new File("employee.txt");
		try {
			fw = new FileWriter(file1);
			fw.write(str);
			fw.flush();
			fw.close();
			System.out.println("We have written into char stream successfully...");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FileWriterClass fwc = new FileWriterClass();
		fwc.writeToFileThruWriter();

	}

}
