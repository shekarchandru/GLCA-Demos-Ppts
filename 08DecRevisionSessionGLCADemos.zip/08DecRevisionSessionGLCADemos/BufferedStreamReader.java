import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class BufferedStreamReader {

	BufferedInputStream bis;
	byte mybytes[] = new byte[100];
	public void readThroughBufferedStream()
	{
		try {
			bis = new BufferedInputStream(new FileInputStream(new File("customer.txt")));
			bis.read(mybytes);
			String str = new String(mybytes);
			System.out.println("the Data Read ");
			System.out.println(str);
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BufferedStreamReader bsr = new BufferedStreamReader();
		bsr.readThroughBufferedStream();

	}

}
